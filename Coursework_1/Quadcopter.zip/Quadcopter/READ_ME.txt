READ ME
Report in file COMP0128_Robotic_Control_Theory_and_Systems_Coursework_1 File
To run each question, run the quadcopter_script.m in each question folder respectively.
Coursework completed by Ela Kanani, Yuangshen Zhang, and Joseph Rowell
