sys = tf([1],[1 0])
c2d(sys, 0.2, 'tustin')
